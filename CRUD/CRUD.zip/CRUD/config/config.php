<?php
//datos de configuracion MYSQL
define('host', '127.0.0.1:3306');
define('user', 'root');
define('password', 'root');
define('database', 'dbpoophp');