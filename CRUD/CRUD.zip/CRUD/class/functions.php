<?php

if(isset($_POST['submit'])){
    if(isset($_POST['email'])){
        include_once('ClassPoo.php');
    
        $user =$_POST['email'];
        $pass =$_POST['pass'];
        $login = new Login();
        $login ->entrarDatos($user, $pass);
        $login ->logear();
        $response = $login->logear();
    
        if($response === "true"){
            header("location:../index.php");
            echo'<script language"javascript">alert("Bienvenido Usuario")</script>';
        } else{
            $msj = "El correo ingresado no está registrado";
            header("Location: ../login.php?msj=$msj");
            echo'<script language"javascript">alert("Error en datos")</script>';
        }
    }
}
