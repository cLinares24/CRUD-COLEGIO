<?php

class Login{

    public $user ="";
    public $password ="";
    public $usu ="camilo@gmail.com";
    public $pass ="camilo";
    public $cadena ="true";
    public $cadena2 ="false";

    function entrarDatos($variable1,$variable2){
        $this ->user = $variable1;
        $this ->password = $variable2;
    }

    function logear(){

        $us = $this->usu;
        $ps = $this->pass;

        $us1 = $this->user;
        $pas1 = $this->password;

        if(($us === $us1) && ($ps === $pas1)){
            return $this->cadena;
        } else{
            return $this->cadena2;
        }
    }
}